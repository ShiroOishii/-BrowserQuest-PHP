<?php
/**
 * This file is part of workerman.
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the MIT-LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author walkor<walkor@workerman.net>
 * @copyright walkor<walkor@workerman.net>
 * @link http://www.workerman.net/
 * @license http://www.opensource.org/licenses/mit-license.php MIT License
 */
use \Workerman\Worker;

define('GLOBAL_START', true);

// 自动加载类
require_once __DIR__ . '/vendor/autoload.php';
// socket服务端文件
require_once __DIR__ . '/start_worker.php';
// web服务
require_once __DIR__ . '/start_web.php';

Worker::runAll();
